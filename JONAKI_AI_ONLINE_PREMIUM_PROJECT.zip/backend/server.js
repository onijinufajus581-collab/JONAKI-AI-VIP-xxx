import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "20kb" }));

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const APP_TOKEN = process.env.JONAKI_APP_TOKEN;

if (!API_KEY) {
  console.error("OPENAI_API_KEY environment variable is required.");
  process.exit(1);
}
if (!APP_TOKEN) {
  console.error("JONAKI_APP_TOKEN environment variable is required.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey: API_KEY });

app.get("/health", (_req, res) => res.json({ ok: true, app: "JONAKI AI" }));

app.post("/chat", async (req, res) => {
  try {
    if (req.get("x-jonaki-token") !== APP_TOKEN) {
      return res.status(401).json({ error: "Unauthorized app request." });
    }

    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message || message.length > 4000) {
      return res.status(400).json({ error: "Message must be 1-4000 characters." });
    }

    const response = await openai.responses.create({
      model: MODEL,
      instructions: [
        "You are JONAKI AI, a helpful voice assistant.",
        "Reply naturally and concisely in Bengali when the user speaks Bengali.",
        "You cannot directly control the phone or claim an action happened unless the Android app reports it.",
        "For messages, purchases, uploads, account changes, or sharing, ask the user to review and confirm in the target app.",
        "Never request passwords, one-time codes, or payment card secrets."
      ].join(" "),
      input: message,
      max_output_tokens: 500
    });

    res.json({ reply: response.output_text || "দুঃখিত, উত্তর তৈরি করা যায়নি।" });
  } catch (error) {
    console.error("Chat request failed:", error?.message || error);
    res.status(500).json({ error: "AI service temporarily unavailable." });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`JONAKI backend listening on ${PORT}`));
