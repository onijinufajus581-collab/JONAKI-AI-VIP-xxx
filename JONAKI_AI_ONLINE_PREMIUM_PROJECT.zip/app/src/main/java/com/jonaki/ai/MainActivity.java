package com.jonaki.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,10,24), PANEL=Color.rgb(20,25,48), PURPLE=Color.rgb(160,90,255), CYAN=Color.rgb(0,225,255);
    private LinearLayout root, chat;
    private TextView status, orb, listenButton;
    private EditText input;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening=false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        buildUi();
        tts = new TextToSpeech(this, result -> { if(result==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("bn","BD")); });
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
        addMessage("JONAKI AI", "হ্যালো! আমি JONAKI AI। বাংলায় বলো, কী সাহায্য লাগবে?");
    }

    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if(stroke!=0)d.setStroke(2,stroke); return d;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private void buildUi() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,24,20,22); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(0);
        TextView logo=text("✦",30,CYAN,true); header.addView(logo);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(1); brand.setPadding(12,0,0,0);
        brand.addView(text("JONAKI AI",23,Color.WHITE,true));
        brand.addView(text("YOUR VOICE • YOUR ASSISTANT",10,0xff9da8c9,true));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=text("ONLINE",11,0xff65f5c4,true); badge.setPadding(12,8,12,8); badge.setBackground(bg(0xff12352f,30,0xff246b5d)); header.addView(badge);
        root.addView(header);

        LinearLayout hero=new LinearLayout(this); hero.setGravity(Gravity.CENTER); hero.setOrientation(1);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,430); hp.topMargin=18; root.addView(hero,hp);
        orb=text("◉",100,0xffb58cff,true); orb.setGravity(Gravity.CENTER);
        GradientDrawable orbBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff39216c,0xff112f54,0xff141a39});
        orbBg.setShape(GradientDrawable.OVAL); orbBg.setStroke(3,0xff9d6bff); orb.setBackground(orbBg);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(220,220); hero.addView(orb,op);
        orb.setElevation(18);
        status=text("READY TO LISTEN",13,0xff9beeff,true); status.setPadding(0,24,0,8); hero.addView(status);
        hero.addView(text("বাংলায় কথা বলো, আমি সাহায্য করব",14,0xffaab5d0,false));

        TextView section=text("CONVERSATION",12,0xff8e9abb,true); section.setPadding(2,8,0,10); root.addView(section);
        chat=new LinearLayout(this); chat.setOrientation(1); chat.setPadding(12,12,12,12); chat.setBackground(bg(PANEL,24,0xff30395d));
        root.addView(chat,new LinearLayout.LayoutParams(-1,-2));

        input=new EditText(this); input.setSingleLine(false); input.setTextColor(Color.WHITE); input.setHintTextColor(0xff7783a5);
        input.setHint("এখানে লিখো অথবা মাইক্রোফোন চাপো..."); input.setPadding(16,14,16,14); input.setBackground(bg(0xff171d35,18,0xff3b456b));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.topMargin=16; root.addView(input,ip);

        Button send=new Button(this); send.setText("SEND TO JONAKI  ➤"); send.setTextColor(Color.WHITE); send.setBackground(bg(0xff713fe0,18,0xffa78bfa));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,56); sp.topMargin=10; root.addView(send,sp);
        send.setOnClickListener(v->{String q=input.getText().toString().trim(); if(!q.isEmpty()){input.setText(""); handle(q);}});

        Button mic=new Button(this); mic.setText("🎙  START VOICE"); mic.setTextColor(Color.WHITE); mic.setBackground(bg(0xff123b50,18,CYAN));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,58); mp.topMargin=10; root.addView(mic,mp);
        mic.setOnClickListener(v->{ if(listening) stopListening(); else startListening(); });
        listenButton=text("STOP LISTENING",12,0xffffa8b7,true); listenButton.setGravity(Gravity.CENTER); listenButton.setPadding(12,14,12,14); root.addView(listenButton);
        listenButton.setOnClickListener(v->stopListening());

        TextView foot=text("AI responses require internet and a configured backend.",10,0xff687595,false);
        foot.setGravity(Gravity.CENTER); foot.setPadding(0,14,0,0); root.addView(foot);
    }

    private void addMessage(String who,String msg) {
        TextView t=text(who+"\n"+msg,14,Color.WHITE,false); t.setPadding(13,12,13,12);
        t.setBackground(bg(who.equals("YOU")?0xff25345a:0xff252044,18,who.equals("YOU")?0xff4264a2:0xff624a9d));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=9; chat.addView(t,p);
    }
    private void handle(String q) {
        addMessage("YOU",q); status.setText("THINKING...");
        String lower=q.toLowerCase(Locale.ROOT);
        if(lower.contains("youtube") || lower.contains("ইউটিউব")) {
            String term=q.replaceAll("(?i)youtube|ইউটিউব|গান|সার্চ করো|খুঁজে দাও","").trim();
            if(term.isEmpty()) term=q;
            addMessage("JONAKI AI","YouTube search খুলছি।");
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(term))));
            status.setText("READY"); return;
        }
        if(lower.contains("whatsapp") || lower.contains("হোয়াটসঅ্যাপ") || lower.contains("হোয়াটসঅ্যাপ")) {
            addMessage("JONAKI AI","WhatsApp খুলছি। Contact বেছে নিয়ে মেসেজ দেখে নিজে Send করবে।");
            launchPackage("com.whatsapp"); status.setText("READY"); return;
        }
        if(lower.contains("tiktok") || lower.contains("টিকটক")) {
            addMessage("JONAKI AI","TikTok খুলছি। ভিডিও নির্বাচন ও পোস্ট করার আগে তুমি নিজে দেখে নিশ্চিত করবে।");
            launchPackage("com.zhiliaoapp.musically"); status.setText("READY"); return;
        }
        if(lower.contains("facebook") || lower.contains("ফেসবুক")) {
            launchPackage("com.facebook.katana"); addMessage("JONAKI AI","Facebook খোলার চেষ্টা করছি।"); status.setText("READY"); return;
        }
        askBackend(q);
    }
    private void launchPackage(String pkg) {
        Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
        if(i!=null) startActivity(i);
        else startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id="+pkg)));
    }
    private void askBackend(String q) {
        new Thread(()->{
            HttpURLConnection c=null;
            try {
                String base=BuildConfig.BACKEND_URL;
                if(base.contains("YOUR-BACKEND-DOMAIN")) throw new Exception("Backend URL সেট করা হয়নি। README দেখো।");
                URL u=new URL(base.replaceAll("/+$","")+"/chat");
                c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(45000);
                c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                JSONObject body=new JSONObject(); body.put("message",q);
                try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}
                int code=c.getResponseCode(); InputStream is=code<400?c.getInputStream():c.getErrorStream();
                ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
                while((n=is.read(buf))!=-1)out.write(buf,0,n);
                JSONObject data=new JSONObject(out.toString("UTF-8"));
                if(code>=400) throw new Exception(data.optString("error","Backend error "+code));
                String answer=data.optString("reply","দুঃখিত, উত্তর পাওয়া যায়নি।");
                runOnUiThread(()->{addMessage("JONAKI AI",answer); status.setText("READY"); if(tts!=null)tts.speak(answer,TextToSpeech.QUEUE_FLUSH,null,"jonaki");});
            } catch(Exception e) {
                String err=e.getMessage()==null?"Connection error":e.getMessage();
                runOnUiThread(()->{addMessage("JONAKI AI","সংযোগ সমস্যা: "+err); status.setText("READY");});
            } finally {if(c!=null)c.disconnect();}
        }).start();
    }
    private void startListening() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){addMessage("JONAKI AI","এই ফোনে Speech Recognition পাওয়া যাচ্ছে না।");return;}
        if(recognizer!=null)recognizer.destroy();
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){status.setText("LISTENING...");}
            public void onBeginningOfSpeech(){orb.setText("◉");}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){status.setText("PROCESSING VOICE...");}
            public void onError(int e){listening=false;status.setText("READY");}
            public void onResults(Bundle b){ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); listening=false; if(a!=null&&!a.isEmpty())handle(a.get(0));}
            public void onPartialResults(Bundle b){}
            public void onEvent(int e,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        listening=true; recognizer.startListening(i);
    }
    private void stopListening(){listening=false;if(recognizer!=null){recognizer.stopListening();recognizer.cancel();}status.setText("READY");}
    @Override protected void onDestroy(){stopListening();if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}